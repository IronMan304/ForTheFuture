<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">

   <a href="<?php echo e(route('import.product')); ?>" class="btn btn-info rounded-pill waves-effect waves-light">Import </a>  
   &nbsp;&nbsp;&nbsp;
   <a href="<?php echo e(route('export')); ?>" class="btn btn-danger rounded-pill waves-effect waves-light">Export </a>  
   &nbsp;&nbsp;&nbsp;

      <a href="<?php echo e(route('add.product')); ?>" class="btn btn-primary rounded-pill waves-effect waves-light">Add Product </a>  
                                        </ol>
                                    </div>
                                    <h4 class="page-title">All Product</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                     
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Supplier</th>
                                <th>Code</th>
                                <th>Stock</th> 
                            </tr>
                        </thead>
                    
    
        <tbody>
        	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td> <img src="<?php echo e(asset($item->product_image)); ?>" style="width:50px; height: 40px;"> </td>
                <td><?php echo e($item->product_name); ?></td>
                <td><?php echo e($item['category']['category_name']); ?></td>
                <td><?php echo e($item['supllier']['name']); ?></td>
                <td><?php echo e($item->product_code); ?></td>
                <td> <button class="btn btn-warning waves-effect waves-light"><?php echo e($item->product_store); ?></button> </td>
      
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->


                      
                        
                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-point-of-sale-master\resources\views/backend/stock/all_stock.blade.php ENDPATH**/ ?>