<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
      
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Pending Orders</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                     
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Customer</th>
                                <th>Order Date</th>
                                <th>Payment</th>
                                <th>Invoice</th>
                                <th>Cash</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    
    
        <tbody>
        	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($item['customer']['name']); ?></td>
                <td><?php echo e($item->service_order_date); ?></td>
                <td><?php echo e($item->service_payment_status); ?></td>
                <td><?php echo e($item->service_invoice_no); ?></td>
                <td><?php echo e($item->service_pay); ?></td>
                <td> <span class="badge bg-danger"><?php echo e($item->service_order_status); ?></span> </td>
                <td>
<a href="<?php echo e(route('service_order.details',$item->id)); ?>" class="btn btn-blue rounded-pill waves-effect waves-light"> Details </a> 

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->


                      
                        
                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/backend/service_order/service_pending_order.blade.php ENDPATH**/ ?>