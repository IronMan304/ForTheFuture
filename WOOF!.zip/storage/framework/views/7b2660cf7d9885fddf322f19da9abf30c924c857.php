<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8" />
        <title> Pet Supplies Management System | Dashboard </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/woof!-logo.ico')); ?>">

        <!-- Plugins css -->
        <link href="<?php echo e(asset('backend/assets/libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/selectize/css/selectize.bootstrap3.css')); ?>" rel="stylesheet" type="text/css" />
        
        <!-- Bootstrap css -->
        <link href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- App css -->
        <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style"/>
        <!-- icons -->
        <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Head js -->
        <script src="<?php echo e(asset('backend/assets/js/head.js')); ?>"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        



  <!-- dataTables -->
        <link href="<?php echo e(asset('backend/assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/assets/libs/datatables.net-select-bs5/css//select.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
  <!-- dataTables end -->





<!-- toastr -->

         <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >
<!-- toastr -->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    </head>

    <!-- body start -->
    <body data-layout-mode="default" data-theme="dark" data-topbar-color="dark" data-menu-position="fixed" data-leftbar-color="dark" data-leftbar-size='default' data-sidebar-user='false'>

        <!-- Begin page -->
        <div id="wrapper">

            
            <!-- Topbar Start -->
           <?php echo $__env->make('body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Topbar -->

            <!-- ========== Left Sidebar Start ========== -->
           <?php echo $__env->make('body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
               
               <?php echo $__env->yieldContent('admin'); ?>

                <!-- Footer Start -->
                <?php echo $__env->make('body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- Right Sidebar -->
        
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- Vendor js -->
        <script src="<?php echo e(asset('backend/assets/js/vendor.min.js')); ?>"></script>

        <!-- Plugins js-->
        <script src="<?php echo e(asset('backend/assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

        <script src="<?php echo e(asset('backend/assets/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>

        <!-- Dashboar 1 init js-->
        <script src="<?php echo e(asset('backend/assets/js/pages/dashboard-1.init.js')); ?>"></script>

        <!-- App js-->
        <script src="<?php echo e(asset('backend/assets/js/app.min.js')); ?>"></script>
        




      <!-- datatables js -->
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
        <!-- third party js ends -->

       
        <script src="<?php echo e(asset('backend/assets/js/pages/datatables.init.js')); ?>"></script>
 <!-- Datatables Eend -->




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
 <script src="<?php echo e(asset('backend/assets/js/code.js')); ?>"></script>
 
  <script src="<?php echo e(asset('backend/assets/js/validate.min.js')); ?>"></script>



         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
 if("<?php echo e(Session::has('message')); ?>"){  
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;

    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
}
</script>


    </body>
</html><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>