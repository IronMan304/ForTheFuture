 <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> &copy; PSMS by <a href="">Inatilleza</a> 
                            </div>
                            
                        </div>
                    </div>
                </footer><?php /**PATH C:\Users\jerec\Downloads\htdocs\WOOF!\resources\views/body/footer.blade.php ENDPATH**/ ?>