<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">POS</a></li>
                        </ol>
                    </div>
                    <h4 class="page-title">Order Product</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
       
        <div class="row">
            <div class="col-lg-6 col-xl-6">
                <div class="card text-center">
                    <div class="card-body">
                        <!-- ... -->
                        <div class="table-responsive">
    <table class="table table-bordered border-primary mb-0">
        <thead>
            <tr>
                <th>Name</th>
                <th>QTY</th>
                <th>Price</th>
                <th>SubTotal</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $allcart = Cart::content();
            ?>

            <?php $__currentLoopData = $allcart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cart->name); ?></td>
                <td>
                    <form method="post" action="<?php echo e(url('/cart-update/'.$cart->rowId)); ?>">
                        <?php echo csrf_field(); ?>

                        <?php
                        $item = $product->firstWhere('id', $cart->id);
                        $maxQty = $item ? $item->product_store : 0;
                        ?>

                        <input type="number" name="qty" value="<?php echo e($cart->qty); ?>" style="width:40px;" min="1" max="<?php echo e($maxQty); ?>" onchange="validateQuantity(this)">
                        <button type="submit" class="btn btn-sm btn-success" style="margin-top:-2px ;">
                            <i class="fas fa-check"></i>
                        </button>
                    </form>
                </td>
                <td><?php echo e($cart->price); ?></td>
                <td><?php echo e($cart->price * $cart->qty); ?></td>
                <td>
                    <a href="<?php echo e(url('/cart-remove/'.$cart->rowId)); ?>">
                        <i class="fas fa-trash-alt" style="color:#ffffff"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <table id="basic-datatable" class="table dt-responsive nowrap w-100"></table>
</div>

                        <!-- ... -->
                        <div class="bg-primary">
                            <br>
                            <p style="font-size:18px; color:#fff"> Quantity: <?php echo e(Cart::count()); ?> </p>
                            <p style="font-size:18px; color:#fff"> SubTotal: <?php echo e(Cart::subtotal()); ?> </p>
                            <p style="font-size:18px; color:#fff"> Vat: <?php echo e(Cart::tax()); ?> </p>
                            <p>
                                <h2 class="text-white">Total</h2>
                                <h1 class="text-white"><?php echo e(Cart::total()); ?></h1>
                            </p>
                            <br>
                        </div>

                        <br>
                        <form id="myForm" method="post" action="<?php echo e(url('/create-invoice')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="firstname" class="form-label">All Customer</label>
                                <a href="<?php echo e(route('add.customer')); ?>" class="btn btn-primary rounded-pill waves-effect waves-light mb-2">Add Customer</a>
                                <select name="customer_id" class="form-select" id="example-select">
                                    <option selected disabled>Select Customer</option>
                                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cus->id); ?>"><?php echo e($cus->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button class="btn btn-blue waves-effect waves-light">Create Invoice</button>
                        </form>
                    </div>
                </div>
            </div> <!-- end card -->
            
            <div class="col-lg-6 col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <div class="tab-pane" id="settings">
                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>Image</th>
                                        <th>Category</th>
                                        <th>Product</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <form method="post" action="<?php echo e(url('/add-cart')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                            <input type="hidden" name="name" value="<?php echo e($item->product_name); ?>">
                                            <input type="hidden" name="qty" value="1">
                                            <input type="hidden" name="price" value="<?php echo e($item->selling_price); ?>">
                                            <td><?php echo e($key+1); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($item->product_image)); ?>" style="width:50px; height: 40px;">
                                            </td>
                                            <td><?php echo e($item->category->category_name); ?></td>
                                            <td><?php echo e($item->product_name); ?></td>
                                            <td>
                                                
                                                <?php if($item->product_store <= 0): ?>
                                                <button type="button" class="btn btn-secondary" disabled>Out of Stock</button>
                                                <?php else: ?>
                                                <button type="submit" style="font-size: 20px; color: #000;">
                                                    <i class="fas fa-plus-square"></i>
                                                </button>
                                                <?php endif; ?>
                                            </td>
                                        </form>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>
      
        <!-- end row-->
    </div> <!-- container -->
</div> <!-- content -->

<script type="text/javascript">
    $(document).ready(function () {
        $('#myForm').validate({
            rules: {
                customer_id: {
                    required: true,
                },
            },
            messages: {
                customer_id: {
                    required: 'Please Select Customer',
                },
            },
            errorElement: 'span',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
        });
    });

    function validateQuantity(input) {
        var maxStock = parseInt(input.getAttribute('product_store'));
        var quantity = parseInt(input.value);
        if (quantity > maxStock) {
            alert("Input value cannot exceed the current stock available!");
            input.value = maxStock;
        }
    }
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/backend/pos/pos_page.blade.php ENDPATH**/ ?>