<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
   <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#signup-modal">Add Service Category</button> 
                                        </ol>
                                    </div>
                                    <h4 class="page-title">All Service Category</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                     
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th> 
                                <th>Service Category Name </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    
    
        <tbody>
        	<?php $__currentLoopData = $service_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td> 
                <td><?php echo e($item->service_category_name); ?></td> 
                <td>
<a href="<?php echo e(route('edit.service_category',$item->id)); ?>" class="btn btn-blue rounded-pill waves-effect waves-light">Edit</a>
<a href="<?php echo e(route('delete.service_category',$item->id)); ?>" class="btn btn-danger rounded-pill waves-effect waves-light" id="delete">Delete</a>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->


                      
                        
                    </div> <!-- container -->

                </div> <!-- content -->



        <!-- Signup modal content -->
<div id="signup-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body"> 

  <form class="px-3" method="post" action="<?php echo e(route('service_category.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
             <label for="username" class="form-label">Service Category Name</label>
     <input class="form-control" type="text" name="service_category_name" placeholder="Add Service Category ">
                    </div>
 

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" type="submit">Save Changes</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/backend/service_category/all_service_category.blade.php ENDPATH**/ ?>