 <div class="navbar-custom">
                <div class="container-fluid">
                    <ul class="list-unstyled topnav-menu float-end mb-0">

                    <?php if(Auth::user()->can('roles.menu')): ?>
                    <li class="dropdown d-none d-xl-block">
                            <a class="nav-link dropdown-toggle waves-effect waves-light" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                Roles and Permission
                                <i class="mdi mdi-chevron-down"></i> 
                            </a>
                            <div class="dropdown-menu">
                                <!-- item-->
                                <a href="<?php echo e(route('all.permission')); ?>" class="dropdown-item">
                                    <i class="fe-briefcase me-1"></i>
                                    <span>All Permission</span>
                                </a>
    
                                <!-- item-->
                                <a href="<?php echo e(route('all.roles')); ?>" class="dropdown-item">
                                    <i class="fe-user me-1"></i>
                                    <span>All Role</span>
                                </a>
    
                                <!-- item-->
                                <a href="<?php echo e(route('add.roles.permission')); ?>" class="dropdown-item">
                                    <i class="fe-bar-chart-line- me-1"></i>
                                    <span>Assign Permission</span>
                                </a>
                                <div class="dropdown-divider"></div>
    
                                <!-- item-->
                                <a href="<?php echo e(route('all.roles.permission')); ?>" class="dropdown-item">
                                    <i class="fe-headphones me-1"></i>
                                    <span>All Roles in Permission</span>
                                </a>
    
                            </div>
                        </li>

                        <li class="dropdown d-none d-xl-block">
                            <a class="nav-link dropdown-toggle waves-effect waves-light" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                Users
                                <i class="mdi mdi-chevron-down"></i> 
                            </a>
                            <div class="dropdown-menu">
                                <!-- item-->
                                <a href="<?php echo e(route('all.admin')); ?>" class="dropdown-item">
                                    <i class="fe-briefcase me-1"></i>
                                    <span>All User</span>
                                </a>
    
                    
                                </a>
                                <div class="dropdown-divider"></div>
    
                                <!-- item-->
                                <a href="<?php echo e(route('add.admin')); ?>" class="dropdown-item">
                                    <i class="fe-headphones me-1"></i>
                                    <span>Add User</span>
                                </a>
    
                            </div>
                        </li>
                        <?php endif; ?>
    
                        <li class="dropdown d-none d-lg-inline-block">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                                <i class="fe-maximize noti-icon"></i>
                            </a>
                        </li>
    
                        
    
                     
            

        <?php
         $id = Auth::user()->id;
         $adminData = App\Models\User::find($id);

        ?>

    
                        <li class="dropdown notification-list topbar-dropdown">
                            <a class="nav-link dropdown-toggle nav-user me-0 waves-effect waves-light" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">

                                <img src="<?php echo e((!empty($adminData->photo)) ? url('upload/admin_image/'.$adminData->photo) : url('upload/no_image.jpg')); ?>" alt="user-image" class="rounded-circle">
                                <span class="pro-user-name ms-1">
                                    <?php echo e($adminData->name); ?> <i class="mdi mdi-chevron-down"></i> 
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end profile-dropdown ">
                                <!-- item-->
                                <div class="dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
    
        <!-- item-->
        <a href="<?php echo e(route('admin.profile')); ?>" class="dropdown-item notify-item">
            <i class="fe-user"></i>
            <span>My Account</span>
        </a>
    
                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <i class="fe-settings"></i>
                                    <span>Settings</span>
                                </a>
    
            <!-- item-->
            <a href="<?php echo e(route('change.password')); ?>" class="dropdown-item notify-item">
                <i class="fe-lock"></i>
                <span>Change Password </span>
            </a>

                                <div class="dropdown-divider"></div>
    
                                <!-- item-->
       <a href="<?php echo e(route('admin.logout')); ?>" class="dropdown-item notify-item">
                                    <i class="fe-log-out"></i>
                                    <span>Logout</span>
                                </a>
    
                            </div>
                        </li>
    
                       
                    </ul>
    
                    <!-- LOGO -->
                    <div class="logo-box">
                        <a href="index.html" class="logo logo-dark text-center">
                            <span class="logo-sm">
                                <img src="<?php echo e(asset('backend/assets/images/woof!-logo.jpg')); ?>" alt="" height="52">
                                <!-- <span class="logo-lg-text-light">UBold</span> -->
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('backend/assets/images/woof!-logo.jpg')); ?>" alt="" height="52">
                                <!-- <span class="logo-lg-text-light">U</span> -->
                            </span>
                        </a>
    
                        <a href="index.html" class="logo logo-light text-center">
                            <span class="logo-sm">
                                <img src="<?php echo e(asset('backend/assets/images/woof!-logo.jpg')); ?>" alt="" height="52">
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('backend/assets/images/woof!-logo.jpg')); ?>" alt="" height="52">
                            </span>
                        </a>
                    </div>
    
                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                        <li>
                            <button class="button-menu-mobile waves-effect waves-light">
                                <i class="fe-menu"></i>
                            </button>
                        </li>

                        <li>
                            <!-- Mobile menu toggle (Horizontal Layout)-->
                            <a class="navbar-toggle nav-link" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>   
            
                      
     
                    </ul>
                    <div class="clearfix"></div>
                </div>
            </div><?php /**PATH C:\Users\jerec\Downloads\htdocs\WOOF!\resources\views/body/header.blade.php ENDPATH**/ ?>