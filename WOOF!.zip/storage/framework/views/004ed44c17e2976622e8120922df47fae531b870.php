<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
      <a href="<?php echo e(route('add.advance.salary')); ?>" class="btn btn-primary rounded-pill waves-effect waves-light">Add Advance Salary </a>  
                                        </ol>
                                    </div>
                                    <h4 class="page-title">All Pay Salary</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title"><?php echo e(date("F Y")); ?></h4>
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Month</th>
                                <th>Salary</th>
                                <th>Advance</th>
                                <th>Due</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    
    
        <tbody>
            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td> <img src="<?php echo e(asset($item->image)); ?>" style="width:50px; height: 40px;"> </td>
                <td><?php echo e($item->name); ?></td>
                <td><span class="badge bg-info"> <?php echo e(date("F", strtotime('-1 month'))); ?> </span> </td>
                <td> <?php echo e($item->salary); ?> </td>
                <td>
                    <?php if($item['advance']['advance_salary'] == NULL ): ?>
                        <p>No Advance</p>
                    <?php else: ?>
                    <?php echo e($item['advance']['advance_salary']); ?>

                    <?php endif; ?>

                 </td>
                <td>
                    <?php
                    $amount = $item->salary - $item['advance']['advance_salary'];
                    ?>
                    <strong style="color: #fff;"> <?php echo e(round($amount)); ?> </strong>

                 </td>
                <td>
<a href="<?php echo e(route('pay.now.salary',$item->id)); ?>" class="btn btn-blue rounded-pill waves-effect waves-light">Pay Now</a>
 

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->


                      
                        
                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-point-of-sale-master\resources\views/backend/salary/pay_salary.blade.php ENDPATH**/ ?>