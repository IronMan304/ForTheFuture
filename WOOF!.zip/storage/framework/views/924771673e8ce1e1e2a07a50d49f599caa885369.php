
<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
      
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Complete Service Orders</h4>
                                    
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                     
                
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Image</th>
                                <th>Name</th>
                                
                                <th>Payment</th>
                                <th>Invoice</th>
                                <th>Pay</th>
                                <th>Status</th>
                             
                            </tr>
                        </thead>
                    
    
        <tbody>
        <?php
    $finalTotal = 0;
?>
<?php
    $orders = App\Models\ServiceOrder::all(); // Assuming you have an "Order" model and want to fetch all orders
    $finalTotal = 0;
?>
        	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td> <img src="<?php echo e(asset($item->customer->image)); ?>" style="width:50px; height: 40px;"> </td>
                <td><?php echo e($item['customer']['name']); ?></td>
                
                <td><?php echo e($item->service_payment_status); ?></td>
                <td><?php echo e($item->service_invoice_no); ?></td>
                <td><?php echo e($item->total); ?></td>
                <td> <span class="badge bg-success"><?php echo e($item->service_order_status); ?></span> </td>
                <?php
            $finalTotal += $item->total;
        ?>
               
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            
            <div class="row">




<div class="col-md-3 col-xl-4">
    <div class="widget-rounded-circle card">
        <div class="card-body">
            <div class="row">
                <div class="col-6">
                    <div class="avatar-lg rounded-circle bg-success border-success border shadow d-flex justify-content-center align-items-center">
              <i class="fas fa-regular fa-money-bill fa-spin font-22 text-white"></i>
                    </div>
                </div>
                <div class="col-6">
                      <div class="text-end">
                        <h4 class="text-dark mt-1">₱<span data-plugin="counterup"><?php echo e($finalTotal); ?></span></h4>
                        <p> Revenues </p>
                    </div>
                </div>
            </div> <!-- end row-->
        </div>
    </div> <!-- end widget-rounded-circle-->
</div> <!-- end col-->



<div class="col-md-6 col-xl-4">
    <div class="widget-rounded-circle card">
        <div class="card-body">
            <div class="row">
                <div class="col-6">
                    <div class="avatar-lg rounded-circle bg-info border-info border shadow d-flex justify-content-center align-items-center">
                    <i class="fas fa-duotone fa-box fa-bounce font-22  text-white "></i>
                    </div>
                </div>
                <div class="col-6">
                   <div class="text-end">
                        <h4 class="text-dark mt-1"> <span data-plugin="counterup"><?php echo e(count($servicecompleteorder)); ?></span></h4>
                        <p >Complete Order </p>
                    </div>
                </div>
            </div> <!-- end row-->
        </div>
    </div> <!-- end widget-rounded-circle-->
</div> <!-- end col-->

<div class="col-md-6 col-xl-4">
    <div class="widget-rounded-circle card">
        <div class="card-body">
            <div class="row">
                <div class="col-6">
                    <div class="avatar-lg rounded-circle bg-warning border-warning border shadow d-flex justify-content-center align-items-center">
                        <i class="fe-eye fa-beat font-22 avatar-title text-white"></i>
                    </div>
                </div>
                <div class="col-6">
                   <div class="text-end">
                        <h4 class="text-dark mt-1"> <span data-plugin="counterup"><?php echo e(count($servicependingorder)); ?></span></h4>
                        <p >Pending Order </p>
                    </div>
                </div>
            </div> <!-- end row-->
        </div>
    </div> <!-- end widget-rounded-circle-->
</div> <!-- end col-->
</div>
            
           

          
           
            
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->


                      
                        
                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/body/service_history.blade.php ENDPATH**/ ?>