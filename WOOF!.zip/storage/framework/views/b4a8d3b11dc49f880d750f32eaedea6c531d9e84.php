<div class="left-side-menu">

<div class="h-100" data-simplebar>

    <!-- User box -->


    <!--- Sidemenu -->
    <div id="sidebar-menu">

        <ul id="side-menu">
        <li class="menu-title">Navigation</li>

<li>
    <a href="#sidebarDashboards" data-bs-toggle="collapse">
        <i class="mdi mdi-view-dashboard-outline"></i>
        <span class="badge bg-success rounded-pill float-end"></span>
        <span> Dashboards </span>
        <span class="menu-arrow"></span>
    </a>
    <div class="collapse" id="sidebarDashboards">
        <ul class="nav-second-level">
            <li>
                <a href="<?php echo e(url('/dashboard')); ?>">Overall Dashboard</a>
            </li>
            <li>
                <a href="<?php echo e(url('/product_dashboard')); ?>">Product Dashboard</a>
            </li>
            <li>
                <a href="<?php echo e(url('/service_dashboard')); ?>">Service Dashboard</a>
            </li>
           
        </ul>
    </div>
</li>

            





<li class="menu-title mt-2">Cashier</li>

<?php if(Auth::user()->can('pos.menu')): ?>
<li>
<a href="<?php echo e(route('pos')); ?>">
<span class="badge bg-pink float-end">Buy</span>
<i class="mdi mdi-view-dashboard-outline"></i>
<span> Product </span>
</a>
</li>

<li>
<a href="<?php echo e(route('service.pos')); ?>">
<span class="badge bg-pink float-end">Avail</span>
<i class="mdi mdi-view-dashboard-outline"></i>
<span> Service </span>
</a>
</li>


<?php endif; ?>




            <li class="menu-title mt-2">Management</li>

           
<?php if(Auth::user()->can('employee.menu')): ?>
<li>
<a href="#sidebarEcommerce" data-bs-toggle="collapse">
<i class="mdi mdi-cart-outline"></i>
<span> Employee Manage  </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="sidebarEcommerce">
<ul class="nav-second-level">
<?php if(Auth::user()->can('employee.all')): ?>
<li>
    <a href="<?php echo e(route('all.employee')); ?>">All Employee</a>
</li>
<?php endif; ?>
<?php if(Auth::user()->can('employee.add')): ?>
<li>
    <a href="<?php echo e(route('add.employee')); ?>">Add Employee </a>
</li>
<?php endif; ?>
</ul>
</div>
</li>
<?php endif; ?>
            
<?php if(Auth::user()->can('customer.menu')): ?>
<li>
<a href="#sidebarCrm" data-bs-toggle="collapse">
    <i class="mdi mdi-account-multiple-outline"></i>
    <span> Customer Manage   </span>
    <span class="menu-arrow"></span>
</a>
<div class="collapse" id="sidebarCrm">
    <ul class="nav-second-level">
<?php if(Auth::user()->can('customer.all')): ?>
<li>
<a href="<?php echo e(route('all.customer')); ?>">All Customer</a>
</li>
<?php endif; ?>
<?php if(Auth::user()->can('customer.add')): ?>
<li>
<a href="<?php echo e(route('add.customer')); ?>">Add Customer</a>
</li>
<?php endif; ?>
         
    </ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('supplier.menu')): ?>
<li>
<a href="#sidebarEmail" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Supplier Manage </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="sidebarEmail">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('all.supplier')); ?>">All Supplier</a>
    </li>
    <li>
        <a href="<?php echo e(route('add.supplier')); ?>">Add Supplier</a>
    </li>
    
</ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('salary.menu')): ?>
<li>
<a href="#salary" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Employee Salary </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="salary">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('add.advance.salary')); ?>">Add Advance Salary</a>
    </li>
    <li>
        <a href="<?php echo e(route('all.advance.salary')); ?>">All Advance Salary</a>
    </li>

     <li>
        <a href="<?php echo e(route('pay.salary')); ?>">Pay Salary</a>
    </li> 

    <li>
        <a href="<?php echo e(route('month.salary')); ?>">Last Month Salary</a>
    </li>
    
</ul>
</div>
</li>
<?php endif; ?>


<?php if(Auth::user()->can('attendence.menu')): ?>
<li>
<a href="#attendence" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Employee Attendence </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="attendence">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('employee.attend.list')); ?>">Employee Attendence List </a>
    </li>

</ul>
</div>
</li>

<?php endif; ?>

<li class="menu-title mt-2">Product Menu</li>

<?php if(Auth::user()->can('category.menu')): ?>
<li>
<a href="#category" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Product Category </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="category">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('all.category')); ?>">All Category </a>
    </li>

</ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('product.menu')): ?>
<li>
<a href="#product" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Products  </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="product">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('all.product')); ?>">All Product </a>
    </li>

     <li>
        <a href="<?php echo e(route('add.product')); ?>">Add Product </a>
    </li>
 
</ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('orders.menu')): ?>
<li>
<a href="#orders" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Product Orders  </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="orders">
<ul class="nav-second-level">
<li>
<a href="<?php echo e(route('pending.order')); ?>">Pending Orders </a>
</li>

<li>
<a href="<?php echo e(route('complete.order')); ?>">Complete Orders </a>
</li>



</ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('stock.menu')): ?>

<li>
<a href="#stock" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Inventory   </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="stock">
<ul class="nav-second-level">
<li>
<a href="<?php echo e(route('stock.manage')); ?>">Stock </a>
</li>


</ul>
</div>
</li>
<?php endif; ?>

<?php if(Auth::user()->can('service.menu')): ?>
<li class="menu-title mt-2">Service Menu</li>

<li>
<a href="#serviceCategory" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Service Category </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="serviceCategory">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('all.service_category')); ?>">All Category </a>
    </li>

</ul>
</div>
</li>



<li>
<a href="#service" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Services  </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="service">
<ul class="nav-second-level">
    <li>
        <a href="<?php echo e(route('all.service')); ?>">All Service </a>
    </li>

     <li>
        <a href="<?php echo e(route('add.service')); ?>">Add Service </a>
    </li>
     

</ul>
</div>
</li>



<li>
<a href="#service_orders" data-bs-toggle="collapse">
<i class="mdi mdi-email-multiple-outline"></i>
<span> Service Orders  </span>
<span class="menu-arrow"></span>
</a>
<div class="collapse" id="service_orders">
<ul class="nav-second-level">
<li>
<a href="<?php echo e(route('service_pending.order')); ?>">Pending Service </a>
</li>

<li>
<a href="<?php echo e(route('service_complete.order')); ?>">Complete Service </a>
</li>



</ul>
</div>
</li>
<?php endif; ?>



             
          

            <li class="menu-title mt-2"></li>

<?php if(Auth::user()->can('expenses.menu')): ?>
        <li>
            <a href="#sidebarAuth" data-bs-toggle="collapse">
                <i class="mdi mdi-account-circle-outline"></i>
                <span>Expense </span>
                <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="sidebarAuth">
<ul class="nav-second-level">
<li>
<a href="<?php echo e(route('add.expense')); ?>">Add Expense</a>
</li>
<li>
<a href="<?php echo e(route('today.expense')); ?>">Today Expense</a>
</li>
<li>
<a href="<?php echo e(route('month.expense')); ?>">Monthly Expense</a>
</li>
<li>
<a href="<?php echo e(route('year.expense')); ?>">Yearly Expense</a>
</li>

</ul>
            </div>
        </li>

<?php endif; ?>





         

         

          

               
                    </ul>
                </div>
            </li>
        </ul>

    </div>
    <!-- End Sidebar -->

    <div class="clearfix"></div>

</div>
<!-- Sidebar -left -->

</div><?php /**PATH C:\xampp\htdocs\WOOF!\resources\views/body/sidebar.blade.php ENDPATH**/ ?>